package org.apache.maven.archetypes.maven_archetype_quickstart;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
